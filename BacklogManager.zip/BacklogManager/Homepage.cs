using Backlogmanager.Business.DAL;
using Backlogmanager.Domain;
using Microsoft.Data.SqlClient;
using Microsoft.VisualBasic.ApplicationServices;

namespace BacklogManager
{
    public partial class Homepage : Form
    {
        private UserContainer _userContainer;

        public Homepage()
        {
            InitializeComponent();
            _userContainer = new UserContainer();
        }

        private void loadGames(object sender, EventArgs e)
        {

        }

        private void menuButton_Click(object sender, EventArgs e)
        {
            
        }

        private void TestButton_Click(object sender, EventArgs e)
        {
            try
            {
                Guid userId = Guid.NewGuid();
                Domain.User user = new Domain.User(userId, "Thomas", "test@email.com", "test", 0);
                bool success = _userContainer.Add(user);
                if (success)
                {
                    MessageBox.Show("User added successfully.");
                }
                else
                {
                    MessageBox.Show("Failed to add user.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }
    }
}
