﻿namespace BacklogManager
{
    partial class Homepage
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            menuButton = new Button();
            gameLabel = new Label();
            gameDisplay = new PictureBox();
            friendListPanel = new Panel();
            TestButton = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)gameDisplay).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.LightSlateGray;
            panel1.Controls.Add(menuButton);
            panel1.Location = new Point(0, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(1584, 103);
            panel1.TabIndex = 0;
            // 
            // menuButton
            // 
            menuButton.Location = new Point(12, 13);
            menuButton.Name = "menuButton";
            menuButton.Size = new Size(87, 77);
            menuButton.TabIndex = 0;
            menuButton.Text = "Menu";
            menuButton.UseVisualStyleBackColor = true;
            menuButton.Click += menuButton_Click;
            // 
            // gameLabel
            // 
            gameLabel.AutoSize = true;
            gameLabel.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            gameLabel.Location = new Point(58, 119);
            gameLabel.Name = "gameLabel";
            gameLabel.Size = new Size(87, 28);
            gameLabel.TabIndex = 4;
            gameLabel.Text = "Popular:";
            // 
            // gameDisplay
            // 
            gameDisplay.BackColor = SystemColors.ControlDark;
            gameDisplay.Location = new Point(58, 160);
            gameDisplay.Name = "gameDisplay";
            gameDisplay.Size = new Size(240, 325);
            gameDisplay.TabIndex = 6;
            gameDisplay.TabStop = false;
            // 
            // friendListPanel
            // 
            friendListPanel.BackColor = Color.LightSteelBlue;
            friendListPanel.Location = new Point(1191, 102);
            friendListPanel.Name = "friendListPanel";
            friendListPanel.Size = new Size(393, 753);
            friendListPanel.TabIndex = 13;
            // 
            // TestButton
            // 
            TestButton.Location = new Point(439, 178);
            TestButton.Name = "TestButton";
            TestButton.Size = new Size(94, 73);
            TestButton.TabIndex = 14;
            TestButton.Text = "TestButton";
            TestButton.UseVisualStyleBackColor = true;
            TestButton.Click += TestButton_Click;
            // 
            // Homepage
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1582, 853);
            Controls.Add(TestButton);
            Controls.Add(friendListPanel);
            Controls.Add(gameDisplay);
            Controls.Add(gameLabel);
            Controls.Add(panel1);
            Name = "Homepage";
            Text = "Form1";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)gameDisplay).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button menuButton;
        private Label gameLabel;
        private PictureBox gameDisplay;
        private Panel friendListPanel;
        private Button TestButton;
    }
}
