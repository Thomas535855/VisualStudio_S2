﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BacklogManager.Domain
{
    public class Game
    {
        public string Title {  get; set; }
        public DateTime ReleaseYear { get; set; }
        public string Genre { get; set; }

        public Game(string title, DateTime releaseYear, string genre)
        {
            Title = title;
            ReleaseYear = releaseYear;
            Genre = genre;
        }

    }
}
