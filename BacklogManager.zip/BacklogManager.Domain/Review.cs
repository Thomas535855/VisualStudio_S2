﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BacklogManager.Domain
{
    public class Review
    {
        public int ReviewId { get; set; }
        public int Rating { get; set; }
        public string Description { get; set; }

        public Review(int reviewId, int rating, string description) 
        {
            ReviewId = reviewId;
            Rating = rating;
            Description = description;
        }
    }
}
