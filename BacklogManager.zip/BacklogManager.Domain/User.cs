﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BacklogManager.Domain
{
    public class User
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public int Points { get; set; }
        
        public User(int userId, string username, string email, string password, int points) 
        { 
            UserId = userId;
            Username = username;
            Email = email;
            Password = password;
            Points = points;
        }
    }
}
