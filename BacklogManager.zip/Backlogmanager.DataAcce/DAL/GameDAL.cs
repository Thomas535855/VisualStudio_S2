﻿namespace Backlogmanager.Business.DAL
{
    public class GameDAL
    {

    }
}
