﻿namespace Backlogmanager.Business.DAL
{
    public class ReviewDAL
    {

    }
}
