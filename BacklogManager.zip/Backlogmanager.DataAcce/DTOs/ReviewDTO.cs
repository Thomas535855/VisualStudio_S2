﻿namespace Backlogmanager.Business.DTOs
{
    public class ReviewDTO
    {
        public int ReviewId { get; set; }
        public int Rating { get; set; }
        public string Description { get; set; }
    }
}
